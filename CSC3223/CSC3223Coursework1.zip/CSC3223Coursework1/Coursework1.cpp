#include <cmath>
#include <vector>
#include <map>

#include "../../Common/Window.h"
#include "../../Common/TextureLoader.h"
#include "../../Common/Vector3.h"
#include "../../Common/Vector4.h"
#include "../../Common/MeshGeometry.h"
#include "../../Common/Maths.h"

#include "../../Plugins/OpenGLRendering/OGLRenderer.h"
#include "../../Plugins/OpenGLRendering/OGLMesh.h"
#include "../../Plugins/OpenGLRendering/OGLShader.h"
#include "../../Plugins/OpenGLRendering/OGLTexture.h"

#include "Renderer.h"
#include "RasterisationMesh.h"


using namespace NCL;
using namespace CSC3223;


// bundle renderobjects
class RenderObjectBundle {
public:
	RenderObjectBundle() {};
	void addObject(RenderObject* ro) {
		rovec.push_back(ro);
	}

	void transform(Matrix4 m) {
		for (int i = 0; i < rovec.size(); i++) {
			Matrix4 mat = m * rovec[i]->GetTransform();
			rovec[i]->SetTransform(mat);
		}
	}
	void deleteAllRenderObjects() {
		for (const RenderObject* ro : rovec) {
			delete ro;
		}
		rovec.clear();
	}
	std::vector<RenderObject*> getRovec() {
		return rovec;
	}

private:
	std::vector<RenderObject*> rovec;
};

// moving object setting
enum RockColour {
	PINK,
	YELLOW,
	BLUE
};

// set All Meshes Needed to GPU first to see codes little easier.
std::map<std::string, OGLMesh*> StoreMeshesToGPU() {
    std::map<std::string, OGLMesh*> m;

    // paperShip
    OGLMesh* paperShip = new OGLMesh();
    paperShip->SetPrimitiveType(GeometryPrimitive::Triangles);
    paperShip->SetVertexPositions({ Vector3(0, 0.15, 0), Vector3(0, 2, 0), Vector3(-1, 0, 0), Vector3(1, 0, 0), Vector3(0, 0, -0.75) });
    paperShip->SetVertexColours({ Vector4(0, 0, 1, 1), Vector4(0, 0, 1, 1), Vector4(1, 0, 0, 1), Vector4(0, 1, 0, 1), Vector4(0.75, 0.75, 1, 1) });
    paperShip->SetVertexIndices({ 0, 2, 1, 0, 3, 1, 0, 4, 1 });
    paperShip->UploadToGPU();
    m["paperShip"] = paperShip;

    // planet for planet
    float step = 3.14159265 / 12;
    std::vector<Vector3> planetPositions;
    std::vector<Vector4> planetColours;
    std::vector<Vector2> planetUvCoords;
    for (int i = 0; i < 13; i++) {
        planetPositions.push_back(Vector3(std::cos(step * i), std::sin(step * i), 0));
        planetPositions.push_back(Vector3(std::cos(step * i), -std::sin(step * i), 0));

        planetColours.push_back(Vector4(1, 1, 1, 1));
        planetColours.push_back(Vector4(1, 1, 1, 1));

        planetUvCoords.push_back(Vector2(0.5 * std::cos(step * i) + 0.5, 0.5 * std::sin(step * i) + 0.5));
        planetUvCoords.push_back(Vector2(0.5 * std::cos(step * i) + 0.5, -0.5 * std::sin(step * i) + 0.5));
    }
    OGLMesh* planet = new OGLMesh();
    planet->SetPrimitiveType(GeometryPrimitive::TriangleStrip);
    planet->SetVertexPositions(planetPositions);
    planet->SetVertexColours(planetColours);
    planet->SetVertexTextureCoords(planetUvCoords);
    planet->UploadToGPU();
    m["planet"] = planet;

    // circleRed
    std::vector<Vector4> circleRedColours;
    for (int i = 0; i < 13; i++) {
        circleRedColours.push_back(Vector4(1, 0, 0, 1));
        circleRedColours.push_back(Vector4(1, 0, 0, 1));
    }
    OGLMesh* circleRed = new OGLMesh();
    circleRed->SetPrimitiveType(GeometryPrimitive::TriangleStrip);
    circleRed->SetVertexPositions(planetPositions);
    circleRed->SetVertexColours(circleRedColours);
    circleRed->UploadToGPU();
    m["circleRed"] = circleRed;

    // sphere for stardust
    OGLMesh* sphere = new OGLMesh("sphere.msh");
    sphere->SetPrimitiveType(GeometryPrimitive::Triangles);
    sphere->UploadToGPU();
    m["sphere"] = sphere;

    // fanRock
    std::vector<Vector3> fanPos = { Vector3(0, 0, 0), Vector3(0.8, 0.2, 0), Vector3(0.3, 0.6, 0),
		Vector3(-0.2, 0.9, 0) , Vector3(-0.8, 0.5, 0), Vector3(-rand() % 10 / 10.0, -rand() % 10 / 10.0, 0) , Vector3(0.4, -0.6, 0), Vector3(0.8, -0.5, 0) };
	std::vector<unsigned int> fanindices = { 0, 1, 2, 3, 4, 5, 6, 7, 1 };

    // pink
    OGLMesh* fanRockPink = new OGLMesh();
    fanRockPink->SetPrimitiveType(GeometryPrimitive::TriangleFan);
    fanRockPink->SetVertexPositions(fanPos);
	fanRockPink->SetVertexIndices(fanindices);
    fanRockPink->SetVertexColours({ Vector4(1, 0.1, 0.5, 0.5), Vector4(1, 0.1, 0.5, 0.5), Vector4(1, 0.1, 0.5, 0.5), 
		Vector4(1, 0.1, 0.5, 0.5), Vector4(1, 0.1, 0.5, 0.5), Vector4(1, 0.1, 0.5, 0.5), Vector4(1, 0.1, 0.5, 0.5), Vector4(1, 0.1, 0.5, 0.5) });
    fanRockPink->UploadToGPU();
    m["fanRockPink"] = fanRockPink;

    // yellow
    OGLMesh* fanRockYellow = new OGLMesh();
    fanRockYellow->SetPrimitiveType(GeometryPrimitive::TriangleFan);
    fanRockYellow->SetVertexPositions(fanPos);
	fanRockYellow->SetVertexIndices(fanindices);
	fanRockYellow->SetVertexColours({ Vector4(1, 1, 0, 0.5), Vector4(1, 1, 0, 0.5), Vector4(1, 1, 0, 0.5),
		Vector4(1, 1, 0, 0.5), Vector4(1, 1, 0, 0.5), Vector4(1, 1, 0, 0.5), Vector4(1, 1, 0, 0.5), Vector4(1, 1, 0, 0.5) });
    fanRockYellow->UploadToGPU();
    m["fanRockYellow"] = fanRockYellow;

    // blue
    OGLMesh* fanRockBlue = new OGLMesh();
    fanRockBlue->SetPrimitiveType(GeometryPrimitive::TriangleFan);
    fanRockBlue->SetVertexPositions(fanPos);
	fanRockBlue->SetVertexIndices(fanindices);
	fanRockBlue->SetVertexColours({ Vector4(0, 0.66, 1, 0.5), Vector4(0, 0.66, 1, 0.5), Vector4(0, 0.66, 1, 0.5), 
		Vector4(0, 0.66, 1, 0.5), Vector4(0, 0.66, 1, 0.5), Vector4(0, 0.66, 1, 0.5), Vector4(0, 0.66, 1, 0.5), Vector4(0, 0.66, 1, 0.5), });
    fanRockBlue->UploadToGPU();
    m["fanRockBlue"] = fanRockBlue;

    // rock 
    std::vector<Vector3> rockPos = { Vector3(rand() % 10 / 10.0, rand() % 10 / 10.0, rand() % 10 /10.0), Vector3(-rand() % 10 / 10.0, rand() % 10 / 10.0, rand() % 10 /10.0),  
        Vector3(-rand() % 10 / 10.0, -rand() % 10 / 10.0, rand() % 10 /10.0), Vector3(rand() % 10 / 10.0, -rand() % 10 / 10.0, rand() % 10 /10.0),     
        Vector3(-rand() % 10 / 10.0, -rand() % 10 / 10.0, rand() % 10 /10.0), Vector3(-rand() % 10 / 10.0, rand() % 10 / 10.0, -rand() % 10 /10.0), 
        Vector3(-rand() % 10 / 10.0, -rand() % 10 / 10.0, -rand() % 10 /10.0), Vector3(rand() % 10 / 10.0, -rand() % 10 / 10.0, -rand() % 10 /10.0) };
    std::vector<unsigned int> rockIndices = {0, 1, 2, 0, 3, 2, // front
    0, 4, 5, 0, 1, 5, // upper
    3, 7, 6, 3, 2, 6, // bottom
    4, 5, 6, 4, 7, 6, // back
    3, 0, 4, 3, 7, 4, // right side
    5, 1, 2, 5, 6, 2}; // left side
    std::vector<Vector4> rockColours;
    for(int i = 0; i < rockPos.size(); i++) { 
        // make it look brown
        float redValue = rand() % 50 / 100.0 + 0.4;
        float yellowValue = rand() % 30 / 100.0 + 0.1;
        float blueValue = rand() % 20 / 100.0;
        rockColours.push_back(Vector4(redValue, yellowValue, blueValue, 0.8));
    }
    OGLMesh* rock = new OGLMesh();
    rock->SetPrimitiveType(GeometryPrimitive::Triangles);
    rock->SetVertexPositions(rockPos);
	rock->SetVertexIndices(rockIndices);
    rock->SetVertexColours(rockColours);
    rock->UploadToGPU();
    m["rock"] = rock;

    // squareBlue
    OGLMesh* squareBlue = new OGLMesh();
    squareBlue->SetPrimitiveType(GeometryPrimitive::Triangles);
    squareBlue->SetVertexPositions({ Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(1, 1, 0), Vector3(0, 1, 0) });
    squareBlue->SetVertexIndices({ 0, 1, 3, 3, 2, 1 });
    squareBlue->SetVertexColours({ Vector4(0, 0, 1, 1), Vector4(0, 0, 1, 1), Vector4(0, 0, 1, 1), Vector4(0, 0, 1, 1) });
    squareBlue->UploadToGPU();
    m["squareBlue"] = squareBlue;

    // triangle 
    OGLMesh* triangleGreen = new OGLMesh();
    triangleGreen->SetPrimitiveType(GeometryPrimitive::Triangles);
    triangleGreen->SetVertexPositions({ Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(0.5, std::pow(3, 0.5) / 2, 0) });
    triangleGreen->SetVertexColours({ Vector4(0, 1, 0, 1), Vector4(0, 1, 0, 1) , Vector4(0, 1, 0, 1) , Vector4(0, 1, 0, 1) });
    triangleGreen->UploadToGPU();
    m["triangleGreen"] = triangleGreen;

    // line (red->blue)
    OGLMesh* line = new OGLMesh();
    line->SetPrimitiveType(GeometryPrimitive::Lines);
    line->SetVertexPositions({ Vector3(0, 0, 0), Vector3(1, 0, 0) });
    line->SetVertexColours({ Vector4(1, 0, 0, 1), Vector4(0, 0, 1, 1) });
    line->UploadToGPU();
    m["line"] = line;

    // point
    OGLMesh* point = new OGLMesh();
    point->SetPrimitiveType(GeometryPrimitive::Points);
    point->SetVertexPositions({ Vector3(0, 0, 0) });
    point->SetVertexColours({ Vector4(1, 1, 1, 1) });
    point->UploadToGPU();
    m["point"] = point;

    return m;
}


void background2d(Renderer& renderer, const std::map<std::string, OGLMesh*>& m, int wWidth, int wHeight) {
    int wh = wWidth * wHeight;
    int len = (wWidth > wHeight) ? wWidth : wHeight;

    // papership
    Matrix4 mat = Matrix4::Translation(Vector3(0, 0, -10)) * Matrix4::Rotation(0, Vector3(1, 0, 0)) * Matrix4::Scale(Vector3(15, 15, 15));
    renderer.AddRenderObject(new RenderObject(m.at("paperShip"), mat));
    
    // moonlike and jupyterlike planets
    // moon.png : https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRjAvsL2ShQyALpnCHTk9XTvhEBIfjFWXEhLCfiMfxv9YQZ5JJ5
    TextureBase* moonLikePlanet = OGLTexture::RGBATextureFromFilename("moon.png");
    // jupyter.png : https://www.solarsystemscope.com/textures/download/2k_jupiter.jpg
    TextureBase* jupyterLikePlanet = OGLTexture::RGBATextureFromFilename("jupyter.png");
    int planetNum = 10;
    float biggestSize = 1;
    for (int i = 0; i < planetNum; i++) {
        Vector3 pos;
        pos.x = rand() % len - len / 2;
        pos.y = rand() % len - len /2;
        pos.z = -rand() % 100 - 200;

        float size;
        size = (rand() % 30) + 25;
        if (biggestSize < size) {
            biggestSize = size;
            continue;
        }
        Matrix4 mat = Matrix4::Translation(pos) * Matrix4::Scale(Vector3(size, size, size));
        RenderObject* eachPlanet = new RenderObject(m.at("planet"), mat);

        int surface = rand() % 2;
        switch (surface) {
        case 0:
            eachPlanet->SetBaseTexture(moonLikePlanet);
            break;
        case 1:
            eachPlanet->SetBaseTexture(jupyterLikePlanet);
            break;
        default:
            break;
        }
        renderer.AddRenderObject(eachPlanet);
    }

    // sunlike planet
    // sun.png : https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSx78uyNwdPuMYzgM58WlpPi4KT5spJVa0j86vYoKzFhE1py5K6cQ&s
    TextureBase* sunLikePlanet = OGLTexture::RGBATextureFromFilename("sun.png");
    biggestSize *= 1.5;
    Vector3 pos;
    pos.x = rand() % len - len / 2;
    pos.y = rand() % len - len / 2;
    pos.z = -rand() % 100 - 200;
    Matrix4 matSun = Matrix4::Translation(pos) * Matrix4::Scale(Vector3(biggestSize, biggestSize, biggestSize));
    RenderObject* sun = new RenderObject(m.at("planet"), matSun);
    sun->SetBaseTexture(sunLikePlanet);
    renderer.AddRenderObject(sun);

    // star field
    int starNum = (int)wh * 0.001;
    for (int i = 0; i < starNum; i++) {
        Vector3 pos(0, 0, 0);
        pos.x = rand() % len - len / 2;
        pos.y = rand() % len - len / 2;
        pos.z = - rand() % 200 - 300;
        Matrix4 translation = Matrix4::Translation(pos);
        renderer.AddRenderObject(new RenderObject(m.at("point"), translation));
    }
    
    //orthographic perspective
    Matrix4 proj2d = Matrix4::Orthographic(1.0f, 500.0f, wWidth / 2, -wWidth / 2, wHeight / 2, -wHeight / 2);
    renderer.SetProjectionMatrix(proj2d);
}


void background3d(Renderer& renderer, const std::map<std::string, OGLMesh*>& m, float aspect, float wWidth, float wHeight) {

    // cheap space ship
    Matrix4 mat = Matrix4::Translation(Vector3(0, 0, -25)) * Matrix4::Rotation(-65, Vector3(1, 0, 0)) * Matrix4::Scale(Vector3(5, 5, 5));
    renderer.AddRenderObject(new RenderObject(m.at("paperShip"), mat));

    // little stars 
    int num = 1000;
    for (int i = 0; i < num; i++) {
        Vector3 pos;
        pos.x = rand() % (int)wWidth - wWidth / 2;
        pos.y = rand() % (int)wHeight - wHeight / 2;
        pos.z = rand() % 500 - 400;

        float size;
        size = 0.2 * (rand() % 3);
        Matrix4 mat = Matrix4::Translation(pos) * Matrix4::Scale(Vector3(size, size, size));
        renderer.AddRenderObject(new RenderObject(m.at("sphere"), mat));
    }
    
    // 3d perspective
    Matrix4 proj3d = Matrix4::Perspective(1.0f, 500.0f, aspect, 45.0f);
    renderer.SetProjectionMatrix(proj3d);
}


void displayMyNameWithRasterisationMesh(Renderer& renderer) {

    std::vector<Vector3> vecR = { Vector3(-100, 0, 0), Vector3(-100, 100, 0), Vector3(100, 50, 0), Vector3(100, -100, 0), Vector3(-100, -100, 0) };
    std::vector<Vector3> vecY = { Vector3(0, 0, 0), Vector3(-100, 100, 0), Vector3(100, 100, 0), Vector3(0, -100, 0) };
    std::vector<Vector3> vecO = { Vector3(100, 100, 0), Vector3(-100, 100, 0), Vector3(-100, -100, 0), Vector3(100, -100, 0) };
    std::vector<Vector3> veco = { Vector3(75, 75, 0), Vector3(-75, 75, 0), Vector3(-75, -75, 0), Vector3(75, -75, 0) };
    std::vector<Vector3> vecT = { Vector3(100, 100, 0), Vector3(-100, 100, 0), Vector3(0, 100, 0), Vector3(0, -100, 0) };
    std::vector<Vector3> vecA = { Vector3(100, -100, 0), Vector3(-100, -100, 0), Vector3(50, 0, 0), Vector3(-50, 0, 0), Vector3(0, 100, 0) };
    

    // R
    OGLMesh* R_above = (OGLMesh*)RasterisationMesh::CreateTriangleFromPoints({ vecR[0], vecR[1], vecR[2] },
        { Vector4(0, 1, 0, 1), Vector4(1, 1, 0, 1), Vector4(0, 1, 1, 1) });
    OGLMesh* R_leg1 = (OGLMesh*)RasterisationMesh::CreateLineFromPoints({ vecR[0], vecR[3]},
        { Vector4(0, 1, 0, 1), Vector4(0, 0, 1, 1) }, true);
    OGLMesh* R_leg2 = (OGLMesh*)RasterisationMesh::CreateLineFromPoints({ vecR[0], vecR[4] },
        { Vector4(1, 1, 0, 1), Vector4(0, 1, 1, 1) }, true);

    Matrix4 matR = Matrix4::Translation(Vector3(220 * 1, 0, 0));

    renderer.AddRenderObject(new RenderObject(R_above, matR));
    renderer.AddRenderObject(new RenderObject(R_leg1, matR));
    renderer.AddRenderObject(new RenderObject(R_leg2, matR));

   // Y 
   OGLMesh* Y_above = (OGLMesh*)RasterisationMesh::CreateTriangleFromPoints({ vecY[0], vecY[1], vecY[2] },
       { Vector4(0, 0, 1, 1), Vector4(1, 0, 0, 1), Vector4(1, 0, 0, 1) });
   OGLMesh* Y_leg = (OGLMesh*)RasterisationMesh::CreateLineFromPoints({ vecY[0], vecY[3] },
       { Vector4(0, 0, 1, 1), Vector4(1, 0, 0, 1) }, false);

    Matrix4 matY = Matrix4::Translation(Vector3(220 * 2, 0, 0));

    renderer.AddRenderObject(new RenderObject(Y_above, matY));
    renderer.AddRenderObject(new RenderObject(Y_leg, matY));

    // O 
   OGLMesh* O_outside1 = (OGLMesh*)RasterisationMesh::CreateTriangleFromPoints({ vecO[0], vecO[1], vecO[2] },
       { Vector4(1, 0, 0, 1), Vector4(0, 0, 1, 1), Vector4(1, 0, 0, 1) }, 1);
   OGLMesh* O_outside2 = (OGLMesh*)RasterisationMesh::CreateTriangleFromPoints({ vecO[0], vecO[3], vecO[2]  },
       { Vector4(1, 0, 0, 1), Vector4(0, 1, 0, 1), Vector4(1, 0, 0, 1) } );
   OGLMesh* O_inside1 = (OGLMesh*)RasterisationMesh::CreateTriangleFromPoints({ veco[0], veco[1], veco[2] },
       { Vector4(0, 0, 0, 0.2), Vector4(0, 0, 0, 0.2), Vector4(0, 0, 0, 0.2) }, 1);
   OGLMesh* O_inside2 = (OGLMesh*)RasterisationMesh::CreateTriangleFromPoints({ veco[0], veco[3], veco[2]  },
	   { Vector4(0, 0, 0, 0.5), Vector4(0, 0, 0, 0.5), Vector4(0, 0, 0, 0.5) } );

    Matrix4 matO = Matrix4::Translation(Vector3(220 * 3, 0, 0));

    renderer.AddRenderObject(new RenderObject(O_outside1, matO));
    renderer.AddRenderObject(new RenderObject(O_outside2, matO));
    renderer.AddRenderObject(new RenderObject(O_inside1, matO));
    renderer.AddRenderObject(new RenderObject(O_inside2, matO));

    // T
   OGLMesh* T_above = (OGLMesh*)RasterisationMesh::CreateLineFromPoints({ vecT[0], vecT[1] },
       { Vector4(1, 1, 0, 1), Vector4(0, 1, 1, 1) }, false);
   OGLMesh* T_leg = (OGLMesh*)RasterisationMesh::CreateLineFromPoints({ vecT[2], vecT[3] },
       { Vector4(0.5, 1, 0.5, 1), Vector4(1, 0, 1, 1) }, false);

    Matrix4 matT = Matrix4::Translation(Vector3(220 * 4, 0, 0));

    renderer.AddRenderObject(new RenderObject(T_above, matT));
    renderer.AddRenderObject(new RenderObject(T_leg, matT));

    // A
    OGLMesh* A_above = (OGLMesh*)RasterisationMesh::CreateTriangleFromPoints({ vecA[4], vecA[3], vecA[2] },
        { Vector4(0, 1, 0, 1), Vector4(1, 1, 0, 1), Vector4(0, 1, 1, 1) }, 1);
    OGLMesh* A_leg1 = (OGLMesh*)RasterisationMesh::CreateLineFromPoints({ vecA[0], vecA[2]},
        { Vector4(0, 1, 0, 1), Vector4(0, 0, 1, 1) }, true);
    OGLMesh* A_leg2 = (OGLMesh*)RasterisationMesh::CreateLineFromPoints({ vecA[1], vecA[3] },
        { Vector4(1, 1, 0, 1), Vector4(0, 1, 1, 1) }, true);

    Matrix4 matA = Matrix4::Translation(Vector3(220 * 5, 0, 0));

    renderer.AddRenderObject(new RenderObject(A_above, matA));
    renderer.AddRenderObject(new RenderObject(A_leg1, matA));
    renderer.AddRenderObject(new RenderObject(A_leg2, matA));



    //orthographic perspective
    Matrix4 proj2d = Matrix4::Orthographic(-1.0f, 100.0f, 1400, 0, 500, -500);
    renderer.SetProjectionMatrix(proj2d);

}


void movingObjsSetup(int inNum, int width, int height, 
	std::vector<int>& incol, std::vector<Vector3>& indir, std::vector<Vector3>& inpos, std::vector<Vector3>& inscale, std::vector<Vector3>& inrot) {
	incol.clear();
	indir.clear();
	inpos.clear();
	inrot.clear();
	for (int i = 0; i < inNum; i++) {
		incol.push_back(rand() % 3);

		Vector3 dir;
		dir.x = (rand() % 6 - 3.0) / 6.0;
		dir.y = (rand() % 6 - 3.0) / 6.0;
		dir.z = (rand() % 6 - 3.0) / 6.0;
		indir.push_back(dir);

		Vector3 pos;
		pos.x = rand() % width - width / 2.0;
		pos.y = rand() % height - height / 2.0;
		pos.z = rand() % 100 - 250;
		inpos.push_back(pos);

		Vector3 scale;
		scale.x = rand() % 10 + 20.0;
		scale.y = rand() % 10 + 20.0;
		scale.z = rand() % 10 + 20.0;
		inscale.push_back(scale);

		Vector3 rot;
		rot.x = rand() % 360;
		rot.y = rand() % 360;
		rot.z = rand() % 360;
		inrot.push_back(rot);
	}
}



int main() {
    Window*w = Window::CreateGameWindow("CSC3223 Coursework 1!");
    const float width = w->GetScreenSize().x;
    const float height = w->GetScreenSize().y;
    const float aspect = w->GetScreenAspect();
    Vector3 viewPosition(0, 0, 0);
    Vector3 viewRotation(0, 0, 0);

    if (!w->HasInitialised()) {
        return -1;
    }

    Renderer* renderer = new Renderer(*w);
    std::map<std::string, OGLMesh*> m = StoreMeshesToGPU();

	// default background
    background2d(*renderer, m, width, height); 
    int view = 2; 

	// configure dynamic objects
    bool moving = false;
	int movingObjsNum = 7;
	std::vector<int> movingObjsColours;
	std::vector<Vector3> movingObjsDirections;
	std::vector<Vector3> movingObjsPositions;
	std::vector<Vector3> movingObjsScales;
	std::vector<Vector3> movingObjsRotations;
	movingObjsSetup(movingObjsNum, width, height,
		movingObjsColours, movingObjsDirections, movingObjsPositions, movingObjsScales, movingObjsRotations);
	for (int i = 0; i < movingObjsNum; i++) { // rendering dynamic object first time
		if (view == 2) {
			Matrix4 mat = Matrix4::Translation(movingObjsPositions.at(i)) *
				Matrix4::Scale(movingObjsScales.at(i)) * Matrix4::Rotation(movingObjsRotations.at(i).Length(), Vector3(0, 0, movingObjsRotations.at(i).z));
			int colour = movingObjsColours.at(i);
			switch (colour) {
			case PINK:
				renderer->AddRenderObject(new RenderObject(m["fanRockPink"], mat));
				break;
			case YELLOW:
				renderer->AddRenderObject(new RenderObject(m["fanRockYellow"], mat));
				break;
			case BLUE:
				renderer->AddRenderObject(new RenderObject(m["fanRockBlue"], mat));
				break;
			default:
				renderer->AddRenderObject(new RenderObject(m["fanRockPink"], mat));
				break;
			}
		}
		else if (view == 3) {
			Matrix4 mat = Matrix4::Translation(movingObjsPositions.at(i)) *
				Matrix4::Scale(movingObjsScales.at(i)) * Matrix4::Rotation(movingObjsRotations.at(i).Length(), movingObjsRotations.at(i));
			renderer->AddRenderObject(new RenderObject(m["rock"], mat));
		}
	}


    // rasterisation values setup
    bool depthBuffer = false;
    bool alphaBlend = false;
    float absTime = 0;
    float time = 0;

	// loop starts here
    while (w->UpdateWindow() && !Window::GetKeyboard()->KeyDown(KEYBOARD_ESCAPE)) {

        if(moving){
			// remove added objects once to make them dynamic
			renderer->DeleteRenderObjectsFromBack(movingObjsNum);
            for(int i = 0; i < movingObjsNum; i++) {
                if(view == 2){
                    Matrix4 mat = Matrix4::Translation(movingObjsPositions.at(i)) *
                        Matrix4::Scale(movingObjsScales.at(i)) * Matrix4::Rotation(movingObjsRotations.at(i).Length(), Vector3(0, 0, movingObjsRotations.at(i).z));
					int colour = movingObjsColours.at(i);
                    switch(colour) {
                        case PINK:
                            renderer->AddRenderObject(new RenderObject(m["fanRockPink"], mat));
                            break;
                        case YELLOW: 
                            renderer->AddRenderObject(new RenderObject(m["fanRockYellow"], mat));
                            break;
                        case BLUE:
                            renderer->AddRenderObject(new RenderObject(m["fanRockBlue"], mat));
                            break;
                        default:
							renderer->AddRenderObject(new RenderObject(m["fanRockPink"], mat));
                            break;
                    }
                } else if(view == 3){
                    Matrix4 mat = Matrix4::Translation(movingObjsPositions.at(i)) *
                        Matrix4::Scale(movingObjsScales.at(i)) * Matrix4::Rotation(movingObjsRotations.at(i).Length(), movingObjsRotations.at(i));
					renderer->AddRenderObject(new RenderObject(m["rock"], mat));
                }
            }

            // render here
            absTime = w->GetTimer()->GetTotalTimeSeconds();
            time = w->GetTimer()->GetDeltaTime();
            renderer->Update(time);
            renderer->Render();

            // calculate next positions
            for(int i = 0; i < movingObjsNum; i++) {
                movingObjsPositions[i] = movingObjsPositions.at(i) + movingObjsDirections.at(i);
            }

        } else {
            // render here
            absTime = w->GetTimer()->GetTotalTimeSeconds();
            time = w->GetTimer()->GetDeltaTime();
            renderer->Update(time);
            renderer->Render();
        }
        
        
        // dynamic objects start or stop
		if (Window::GetKeyboard()->KeyPressed(KEYBOARD_1)) {
			moving = !moving;
		}

		// view change
        if (Window::GetKeyboard()->KeyPressed(KEYBOARD_2)) {
            if (view != 2) {
                renderer->DeleteAllRenderObjects();
                background2d(*renderer, m, width, height);
                view = 2;
            }
        }
        if (Window::GetKeyboard()->KeyPressed(KEYBOARD_3)) {
            if (view != 3) {
                renderer->DeleteAllRenderObjects();
                background3d(*renderer, m, aspect, width, height);
                view = 3;
            }
        }

        // basic operation
        if (Window::GetKeyboard()->KeyPressed(KEYBOARD_PRIOR)) {
            w->ShowConsole(true);
        }
        if (Window::GetKeyboard()->KeyPressed(KEYBOARD_NEXT)) {
            w->ShowConsole(false);
        }
        if (Window::GetKeyboard()->KeyPressed(KEYBOARD_HOME)) {
            w->SetFullScreen(true);
        }
        if (Window::GetKeyboard()->KeyPressed(KEYBOARD_END)) {
            w->SetFullScreen(false);
        }
		if (Window::GetKeyboard()->KeyDown(KEYBOARD_BACK)) {
			viewPosition = Vector3(0, 0, 0);
			viewRotation = Vector3(0, 0, 0);
			movingObjsSetup(movingObjsNum, width, height,
				movingObjsColours, movingObjsDirections, movingObjsPositions, movingObjsScales, movingObjsRotations);
		}

        // rasterisation
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F1)) {
            renderer->EnableDepthBuffer(!depthBuffer);
            depthBuffer = !depthBuffer;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F2)) {
            glDepthFunc(GL_LEQUAL);
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F3)) {
            glDepthFunc(GL_ALWAYS);

        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F4)) {
            glDepthFunc(GL_EQUAL);

        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F5)) {
            renderer->EnableAlphaBlending(alphaBlend);
            alphaBlend = !alphaBlend;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F6)) {
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F7)) {
            glBlendFunc(GL_ONE, GL_ONE);
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F8)) {
            glBlendFunc(GL_ONE_MINUS_SRC_COLOR, GL_ONE_MINUS_DST_COLOR);
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F9)) {
            renderer->DeleteAllRenderObjects();
            displayMyNameWithRasterisationMesh(*renderer);
        }

        // move with keyboard
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_I)) {
            viewPosition.z += 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_N)) {
            viewPosition.z -= 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_H)) {
            viewPosition.x += 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_L)) {
            viewPosition.x -= 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_J)) {
            viewPosition.y += 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_K)) {
            viewPosition.y -= 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_A)) {
            viewRotation.z += 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_F)) {
            viewRotation.z -= 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_S)) {
            viewRotation.x += 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_D)) {
            viewRotation.x -= 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_R)) {
            viewRotation.y += 0.5f;
        }
        if (Window::GetKeyboard()->KeyDown(KEYBOARD_B)) {
            viewRotation.y -= 0.5f;
        }
     

        // move with mouse
        if (Window::GetMouse()->ButtonDown(MOUSE_LEFT)) {
            Vector2 direc = Window::GetMouse()->GetRelativePosition();
            viewPosition.x -= direc.x;
            viewPosition.y += direc.y;
        }
        if (Window::GetMouse()->ButtonDown(MOUSE_RIGHT)) {
            if (view == 3) {
                Vector2 direc = Window::GetMouse()->GetRelativePosition();
                viewRotation.x += direc.y;
                viewRotation.y -= direc.x;
            }

            if (view == 2) {

				/*
                Vector2 dir = Window::GetMouse()->GetRelativePosition();
                Vector3 dir3 = Vector3(dir.x, dir.y, 0);
                Vector2 norm = Window::GetMouse()->GetAbsolutePosition();
                norm.Normalise();
                Vector3 norm3 = Vector3(norm.x, norm.y, 0);
                viewRotation.z += Vector3::Cross(norm3, dir3).z;
				*/
            }
        }
        if (Window::GetMouse()->WheelMoved()) {
            viewPosition.z += 3 * Window::GetMouse()->GetWheelMovement();
        }

		// view matrix
        float rotationAbs = viewRotation.Length();
        renderer->SetViewMatrix(Matrix4::Translation(viewPosition) * Matrix4::Rotation(rotationAbs, viewRotation));

		// title
        w->SetTitle(std::to_string(absTime));
    }

    delete renderer;

    Window::DestroyGameWindow();
}